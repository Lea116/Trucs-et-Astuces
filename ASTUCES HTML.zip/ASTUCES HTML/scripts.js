
function changeImg(nom){
    document.getElementById("astucesimg").src = nom;
}